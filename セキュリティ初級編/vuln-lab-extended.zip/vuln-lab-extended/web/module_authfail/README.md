# module_authfail

This folder contains examples and notes about authentication failures and secure alternatives.
