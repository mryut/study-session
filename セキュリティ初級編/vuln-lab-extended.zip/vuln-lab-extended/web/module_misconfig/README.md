# module_misconfig

This folder contains examples and notes about security misconfiguration. Replace with concrete code as needed.
