# module_components

This folder contains examples and notes about vulnerable/outdated components. Use SBOM examples and guidance.
