# module_logging

This folder contains examples and notes about logging and monitoring; include sample logconfig and SIEM hints.
